﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTV_WU_ClientAgent
{
    public class UpdateOption
    {
        public bool IsOfflineModel { get; set; }
        public bool IsDownloadWsusScn2 { get; set; }
        public bool IsNanualDownloadInstall { get; set; }
        public bool IsIncludeSuperseded { get; set; }
        public bool IsRegisterMicrosoftUpdate { get; set; }
        public bool IsRunBackground { get; set; }
        public bool IsAlwaysRunAdministrator { get; set; }
        public string ServiceSource { get; set; }

        public UpdateOption(bool issOfflineModel = false
            , bool isDownloadWsusScn2 = false
            , bool isNanualDownloadInstall = false
            , bool isIncludeSuperseded = false
            , bool isRegisterMicrosoftUpdate = false
            , bool isRunBackground = true
            , bool isAlwaysRunAdministrator = false
            , string serviceSource = ""
            )
        {
            IsOfflineModel = issOfflineModel;
            IsDownloadWsusScn2 = isDownloadWsusScn2;
            IsNanualDownloadInstall = isNanualDownloadInstall;
            IsIncludeSuperseded = isIncludeSuperseded;
            IsRegisterMicrosoftUpdate = isRegisterMicrosoftUpdate;
            IsRunBackground = isRunBackground;
            IsAlwaysRunAdministrator = isAlwaysRunAdministrator;
            ServiceSource = serviceSource;
        }
    }
}
