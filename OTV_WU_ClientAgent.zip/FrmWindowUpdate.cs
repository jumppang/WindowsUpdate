﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WUApiLib;

namespace OTV_WU_ClientAgent
{
    public partial class FrmWindowUpdate : Form
    {
        WuClientAgent _wca;
        UpdateOption _updateOption;
        bool ResultShown = false;
        private bool doUpdte = false;

        public FrmWindowUpdate()
        {
            InitializeComponent();

            _updateOption = new UpdateOption();

            btnReload.Click += BtnReload_Click;
            AppLog.Logger += LineLogger;

            _wca = WuClientAgent.GetInstance();
            _wca.Progress += OnProgress;
            _wca.UpdatesChaged += OnUpdates;
            _wca.Finished += OnFinished;

            if (!_wca.IsActive())
            {
                if (MessageBox.Show(Translate.fmt("msg_wuau"), Program.mName, MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    _wca.EnableWuAuServ();
                    _wca.Init();
                }
            }

            SwitchList(UpdateLists.UpdateHistory);

        }

        DateTime LastCheck = DateTime.MaxValue;
        private bool mSuspendUpdate = false;
        enum UpdateLists
        {
            PendingUpdates,
            InstaledUpdates,
            HiddenUpdates,
            UpdateHistory
        };

        void OnUpdates(object sender, WuClientAgent.UpdatesArgs args)
        {
            //UpdateCounts();
            if (args.Found) // if (agent.CurOperation() == WuAgent.AgentOperation.CheckingUpdates)
            {
                LastCheck = DateTime.Now;
                SetConfig("LastCheck", LastCheck.ToString());
                SwitchList(UpdateLists.PendingUpdates);
            }
            else
            {
                LoadList();

                if (MiscFunc.parseInt(Program.IniReadValue("Options", "Refresh", "0")) == 1 && (_wca.CurOperation() == WuClientAgent.AgentOperation.InstallingUpdates || _wca.CurOperation() == WuClientAgent.AgentOperation.RemoveingUpdates))
                    doUpdte = true;
            }
        }

        bool checkChecks = false;
        bool ignoreChecks = false;

        private UpdateLists CurrentList = UpdateLists.UpdateHistory;


        void LoadList()
        {
            switch (CurrentList)
            {
                case UpdateLists.PendingUpdates: LoadList(_wca.mPendingUpdates); break;
                case UpdateLists.InstaledUpdates: LoadList(_wca.mInstalledUpdates); break;
                case UpdateLists.HiddenUpdates: LoadList(_wca.mHiddenUpdates); break;
                case UpdateLists.UpdateHistory: LoadList(_wca.mUpdateHistory); break;
            }
        }

        string mSearchFilter = null;

        void LoadList(List<MsUpdate> List)
        {
            string INIPath = Program.wrkPath + @"\Updates.ini";


            switch (CurrentList)
            {
                case UpdateLists.PendingUpdates: lvPendingInstall.Items.Clear(); break;
                case UpdateLists.InstaledUpdates: lvInstalled.Items.Clear(); break;
                //case UpdateLists.HiddenUpdates: lvhi); break;
                case UpdateLists.UpdateHistory: lvHistory.Items.Clear(); break;
            }

            List<ListViewItem> items = new List<ListViewItem>();
            for (int i = 0; i < List.Count; i++)
            {
                MsUpdate Update = List[i];
                string State = "";
                switch (Update.State)
                {
                    case MsUpdate.UpdateState.History:
                        switch ((OperationResultCode)Update.ResultCode)
                        {
                            case OperationResultCode.orcNotStarted: State = Translate.fmt("stat_not_start"); break;
                            case OperationResultCode.orcInProgress: State = Translate.fmt("stat_in_prog"); break;
                            case OperationResultCode.orcSucceeded: State = Translate.fmt("stat_success"); break;
                            case OperationResultCode.orcSucceededWithErrors: State = Translate.fmt("stat_success_2"); break;
                            case OperationResultCode.orcFailed: State = Translate.fmt("stat_failed"); break;
                            case OperationResultCode.orcAborted: State = Translate.fmt("stat_abbort"); break;
                        }
                        State += " (0x" + String.Format("{0:X8}", Update.HResult) + ")";
                        break;

                    default:
                        if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Beta) != 0)
                            State = Translate.fmt("stat_beta" + " ");

                        if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Installed) != 0)
                        {
                            State += Translate.fmt("stat_install");
                            if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Uninstallable) != 0)
                                State += " " + Translate.fmt("stat_rem");
                        }
                        else if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Hidden) != 0)
                        {
                            State += Translate.fmt("stat_block");
                            if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Downloaded) != 0)
                                State += " " + Translate.fmt("stat_dl");
                        }
                        else
                        {
                            if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Downloaded) != 0)
                                State += Translate.fmt("stat_dl");
                            else
                                State += Translate.fmt("stat_pending");
                            if ((Update.Attributes & (int)MsUpdate.UpdateAttr.AutoSelect) != 0)
                                State += " " + Translate.fmt("stat_sel");
                            if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Mandatory) != 0)
                                State += " " + Translate.fmt("stat_mand");
                        }

                        if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Exclusive) != 0)
                            State += ", " + Translate.fmt("stat_excl");

                        if ((Update.Attributes & (int)MsUpdate.UpdateAttr.Reboot) != 0)
                            State += ", " + Translate.fmt("stat_reboot");
                        break;
                }


                string[] strings = new string[] {
                    Update.Title,
                    Update.Category,
                    CurrentList == UpdateLists.UpdateHistory ? Update.ApplicationID : Update.KB,
                    Update.Date.ToString(CultureInfo.CurrentUICulture.DateTimeFormat.ShortDatePattern),
                    FileOps.FormatSize(Update.Size),
                    State};

                if (mSearchFilter != null)
                {
                    bool match = false;
                    foreach (string str in strings)
                    {
                        if (str.IndexOf(mSearchFilter, StringComparison.CurrentCultureIgnoreCase) != -1)
                        {
                            match = true;
                            break;
                        }
                    }
                    if (!match)
                        continue;
                }

                ListViewItem item = new ListViewItem(strings);
                item.SubItems[3].Tag = Update.Date;
                item.SubItems[4].Tag = Update.Size;


                item.Tag = Update;

                if (CurrentList == UpdateLists.PendingUpdates)
                {
                    if (MiscFunc.parseInt(Program.IniReadValue(Update.KB, "BlackList", "0", INIPath)) != 0)
                        item.Font = new Font(item.Font.FontFamily, item.Font.Size, FontStyle.Strikeout);
                    else if (MiscFunc.parseInt(Program.IniReadValue(Update.KB, "Select", "0", INIPath)) != 0)
                        item.Checked = true;
                }
                else if (CurrentList == UpdateLists.InstaledUpdates)
                {
                    if (MiscFunc.parseInt(Program.IniReadValue(Update.KB, "Remove", "0", INIPath)) != 0)
                        item.Checked = true;
                }

                string colorStr = Program.IniReadValue(Update.KB, "Color", "", INIPath);
                if (colorStr.Length > 0)
                {
                    Color? color = MiscFunc.parseColor(colorStr);
                    if (color != null)
                        item.BackColor = (Color)color;
                }

                //ListViewGroup lvg = updateView.Groups[Update.Category];
                //if (lvg == null)
                //{
                //    lvg = updateView.Groups.Add(Update.Category, Update.Category);
                //    ListViewExtended.setGrpState(lvg, ListViewGroupState.Collapsible);
                //}
                //item.Group = lvg;
                items.Add(item);
            }

            switch (CurrentList)
            {
                case UpdateLists.PendingUpdates: lvPendingInstall.Items.AddRange(items.ToArray()); break;
                case UpdateLists.InstaledUpdates: lvInstalled.Items.AddRange(items.ToArray()); break;
                //case UpdateLists.HiddenUpdates: lvhi); break;
                case UpdateLists.UpdateHistory: lvHistory.Items.AddRange(items.ToArray()); break;
            }

            // Note: this has caused issues in the past
            //updateView.SetGroupState(ListViewGroupState.Collapsible);
        }

        //private bool suspendChange = false;

        void SwitchList(UpdateLists List)
        {
            //if (suspendChange)
            //    return;

            //suspendChange = true;
            //btnWinUpd.CheckState = List == UpdateLists.PendingUpdates ? CheckState.Checked : CheckState.Unchecked;
            //btnInstalled.CheckState = List == UpdateLists.InstaledUpdates ? CheckState.Checked : CheckState.Unchecked;
            //btnHidden.CheckState = List == UpdateLists.HiddenUpdates ? CheckState.Checked : CheckState.Unchecked;
            //btnHistory.CheckState = List == UpdateLists.UpdateHistory ? CheckState.Checked : CheckState.Unchecked;
            //suspendChange = false;

            //CurrentList = List;

            //switch (CurrentList)
            //{
            //    case UpdateLists.PendingUpdates: lvTobeInstall.Items.AddRange(items.ToArray()); break;
            //    case UpdateLists.InstaledUpdates: lvInstalled.Items.AddRange(items.ToArray()); break;
            //    //case UpdateLists.HiddenUpdates: lvhi); break;
            //    case UpdateLists.UpdateHistory: lvHistory.Items.AddRange(items.ToArray()); break;
            //}

            //updateView.Columns[2].Text = (CurrentList == UpdateLists.UpdateHistory) ? Translate.fmt("col_app_id") : Translate.fmt("col_kb");

            LoadList();

            UpdateState();

        }

        public void SetConfig(string name, string value)
        {
            if (mSuspendUpdate)
                return;
            Program.IniWriteValue("Options", name, value.ToString());
            //var subKey = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Xanatos\Windows Update Manager", true);
            //subKey.SetValue(name, value);
        }



        void OnFinished(object sender, WuClientAgent.FinishedArgs args)
        {
            UpdateState();
            lblStatus.Text = "";
            toolTip.SetToolTip(lblStatus, "");

            ShowResult(args.Op, args.Ret, args.RebootNeeded);
        }

        void OnProgress(object sender, WuClientAgent.ProgressArgs args)
        {
            string Status = GetOpStr(_wca.CurOperation());

            if (args.TotalCount == -1)
            {
                progTotal.Style = ProgressBarStyle.Marquee;
                progTotal.MarqueeAnimationSpeed = 30;
                Status += "...";
            }
            else
            {
                progTotal.Style = ProgressBarStyle.Continuous;
                progTotal.MarqueeAnimationSpeed = 0;

                if (args.TotalPercent >= 0 && args.TotalPercent <= 100)
                    progTotal.Value = args.TotalPercent;

                if (args.TotalCount > 1)
                    Status += " " + args.CurrentIndex + "/" + args.TotalCount + " ";

                //if (args.UpdatePercent != 0)
                //    Status += " " + args.UpdatePercent + "%";
            }
            lblStatus.Text = Status;
            toolTip.SetToolTip(lblStatus, args.Info);

            UpdateState();
        }

        private void UpdateState()
        {
            //checkChecks = false;

            //bool isChecked = updateView.CheckedItems.Count > 0;

            //bool busy = agent.IsBusy();
            //btnCancel.Visible = busy;
            //progTotal.Visible = busy;
            //lblStatus.Visible = busy;

            //bool isValid = agent.IsValid();
            //bool isValid2 = isValid || chkManual.Checked;

            //bool admin = MiscFunc.IsAdministrator() || !MiscFunc.IsRunningAsUwp();

            //bool enable = agent.IsActive() && !busy;
            //btnSearch.Enabled = enable;
            //btnDownload.Enabled = isChecked && enable && isValid2 && (CurrentList == UpdateLists.PendingUpdates);
            //btnInstall.Enabled = isChecked && admin && enable && isValid2 && (CurrentList == UpdateLists.PendingUpdates);
            //btnUnInstall.Enabled = isChecked && admin && enable && (CurrentList == UpdateLists.InstaledUpdates);
            //btnHide.Enabled = isChecked && enable && isValid && (CurrentList == UpdateLists.PendingUpdates || CurrentList == UpdateLists.HiddenUpdates);
            //btnGetLink.Enabled = isChecked && CurrentList != UpdateLists.UpdateHistory;
        }

        private void BtnReload_Click(object sender, EventArgs e)
        {
            if (!_wca.IsActive() || _wca.IsBusy())
                return;

            WuClientAgent.RetCodes ret = WuClientAgent.RetCodes.Undefined;
            if (_updateOption.IsOfflineModel)
                ret = _wca.SearchForUpdates(_updateOption.IsDownloadWsusScn2, _updateOption.IsIncludeSuperseded);
            else
                
            ret = _wca.SearchForUpdates(_updateOption.ServiceSource, _updateOption.IsIncludeSuperseded);

            ShowResult(WuClientAgent.AgentOperation.CheckingUpdates, ret);
        }

        private void ShowResult(WuClientAgent.AgentOperation op, WuClientAgent.RetCodes ret, bool reboot = false)
        {
            if (op == WuClientAgent.AgentOperation.DownloadingUpdates && _updateOption.IsNanualDownloadInstall)
            {
                if (ret == WuClientAgent.RetCodes.Success)
                {
                    //MessageBox.Show(Translate.fmt("msg_dl_done", _wca.dlPath), Program.mName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    AppLog.GetInstance().logLine(Translate.fmt("msg_dl_done", _wca.dlPath));
                    return;
                }
                else if (ret == WuClientAgent.RetCodes.DownloadFailed)
                {
                    //MessageBox.Show(Translate.fmt("msg_dl_err", _wca.dlPath), Program.mName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    AppLog.GetInstance().logLine(Translate.fmt("msg_dl_err", _wca.dlPath));

                    return;
                }
            }

            if (op == WuClientAgent.AgentOperation.InstallingUpdates && reboot)
            {
                if (ret == WuClientAgent.RetCodes.Success)
                {
                    //MessageBox.Show(Translate.fmt("msg_inst_done", _wca.dlPath), Program.mName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    AppLog.GetInstance().logLine(Translate.fmt("msg_inst_done", _wca.dlPath));
                    return;
                }
                else if (ret == WuClientAgent.RetCodes.DownloadFailed)
                {
                    //MessageBox.Show(Translate.fmt("msg_inst_err", _wca.dlPath), Program.mName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    AppLog.GetInstance().logLine(Translate.fmt("msg_inst_err", _wca.dlPath));

                    return;
                }
            }

            string status = "";
            switch (ret)
            {
                case WuClientAgent.RetCodes.Success:
                case WuClientAgent.RetCodes.Abborted:
                case WuClientAgent.RetCodes.InProgress: return;
                case WuClientAgent.RetCodes.AccessError: status = Translate.fmt("err_admin"); break;
                case WuClientAgent.RetCodes.Busy: status = Translate.fmt("err_busy"); break;
                case WuClientAgent.RetCodes.DownloadFailed: status = Translate.fmt("err_dl"); break;
                case WuClientAgent.RetCodes.InstallFailed: status = Translate.fmt("err_inst"); break;
                case WuClientAgent.RetCodes.NoUpdated: status = Translate.fmt("err_no_sel"); break;
                case WuClientAgent.RetCodes.InternalError: status = Translate.fmt("err_int"); break;
                case WuClientAgent.RetCodes.FileNotFound: status = Translate.fmt("err_file"); break;
            }

            string action = GetOpStr(op);

            ResultShown = true;
            //MessageBox.Show(Translate.fmt("msg_err", action, status), Program.mName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            AppLog.GetInstance().logLine(Translate.fmt("msg_err", _wca.dlPath));

            ResultShown = false;
        }

        string GetOpStr(WuClientAgent.AgentOperation op)
        {
            switch (op)
            {
                case WuClientAgent.AgentOperation.CheckingUpdates: return Translate.fmt("op_check");
                case WuClientAgent.AgentOperation.PreparingCheck: return Translate.fmt("op_prep");
                case WuClientAgent.AgentOperation.PreparingUpdates:
                case WuClientAgent.AgentOperation.DownloadingUpdates: return Translate.fmt("op_dl");
                case WuClientAgent.AgentOperation.InstallingUpdates: return Translate.fmt("op_inst");
                case WuClientAgent.AgentOperation.RemoveingUpdates: return Translate.fmt("op_rem");
                case WuClientAgent.AgentOperation.CancelingOperation: return Translate.fmt("op_cancel");
            }
            return Translate.fmt("op_unk");
        }

        void LineLogger(object sender, AppLog.LogEventArgs args)
        {
            logBox.AppendText(args.line + Environment.NewLine);
            logBox.ScrollToCaret();
        }
    }
}
